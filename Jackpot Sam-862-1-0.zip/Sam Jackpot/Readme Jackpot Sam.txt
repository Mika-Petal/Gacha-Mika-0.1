THIS MOD IS NOT SAFE FOR WORK.

Or Youtube. Or strict parents.

Simply open your Stardew valley folder (For most people this is C drive, users, your user name, x86, Steam, Apps, Common, Stardew Valley.)

When you see the folder labled "Contents" 
Take the mod which will also be labeled Contents and past it so that it will overwrite. This will change only one file.

Congratulations! Now your spouse will talk dirty to you (and sweet too) and he will give you rare items almost every day! Enjoy!

